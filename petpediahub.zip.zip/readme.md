# PetPedia Hub

Welcome to **PetPedia Hub**, a website made for all pet lovers! It’s a place where you can explore information about dogs, cats, and birds, learn fun facts, and see adorable pets up close.  

The website has two sides: a **user side** for visitors and an **admin side** for managing content dynamically.

---

## **About the Project**
- The **user side** is designed for pet enthusiasts to explore pets, learn about them, and interact with features like Featured Pet and Pet Care Tips.  
- The **admin side** allows you to add or remove pets and check messages from users.  
- All changes in the admin panel show up instantly on the user side using **localStorage**—no database required.  
- Built using **HTML, CSS, JavaScript, and Bootstrap 5**.  

---

## **What You Can Do**

### For Users:
- Explore pets by category: Dogs, Cats, Birds.  
- See a **Featured Pet of the Week** with detailed information.  
- Read fun pet care tips.  
- Contact us using a form that validates your input live (no errors after submission).  
- Subscribe to a newsletter (static).  

### For Admin:
- View a dashboard showing total pets and messages.  
- Add new pets with name, type, and image.  
- Remove pets when needed.  
- View and delete contact messages.  
- Fully responsive and works on desktop and mobile.

---

## **Pages Included**

**User Side (Client Pages):**
1. `index.html` – Home page  
2. `dogs.html` – Dogs page  
3. `cats.html` – Cats page  
4. `birds.html` – Birds page  
5. `contact.html` – Contact page with validation  
6. `eva.html` – Details of featured pet Eva  

**Admin Side:**
1. `admin.html` – Manage pets and messages  

---

## **Validation Highlights**
- Name: Required, minimum 3 characters  
- Email: Required, valid email format  
- Mobile: Required, 10 digits  
- Subject: Required, minimum 3 characters  
- Message: Required, minimum 10 characters  
- Validation messages appear while typing for a smoother experience  

---

## **How to Run the Website**
1. Download or clone the repository.  
2. Open `index.html` in a browser to explore the user side.  
3. Open `admin.html` in a browser to manage pets and view messages.  
4. Any changes you make in the admin panel reflect immediately on the user side.  

> **Note:** No server or database is needed. All data is stored locally in your browser.

---

## **Project Structure**
